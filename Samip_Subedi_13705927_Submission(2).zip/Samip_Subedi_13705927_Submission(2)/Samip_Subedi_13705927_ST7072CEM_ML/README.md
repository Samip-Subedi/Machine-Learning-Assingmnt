# Analysis of Long-Term Temperature and Rainfall Trends Using Machine Learning
## A Spatiotemporal Regime Clustering and Classification Analysis (1991–2024)

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Plotly](https://img.shields.io/badge/Plotly-Interactive_GUI-indigo.svg)](https://plotly.com/)
[![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-orange.svg)](https://jupyter.org/)
[![Status](https://img.shields.io/badge/Status-Completed-green.svg)]()

## 👤 Student & Module Information
- **Student Name:** Samip Subedi
- **Coventry ID:** 13705927
- **Email ID:** 220234@softwarica.edu.np
- **Module:** Machine Learning (`ST7072CEM`)
- **Institution:** Softwarica College of IT & E-Commerce (Coventry University)

## 📋 Overview
This repository contains the complete implementation of an integrated machine learning framework for the spatiotemporal analysis of long-term temperature and rainfall trends from **1991 to 2024 (34 years, 408 months)**. By combining unsupervised learning (**PCA**, **K-Means Clustering**, and **Ward's Hierarchical Agglomerative Clustering**), composite hydro-thermal index formulation (**CMTI**), **Ordinary Least Squares (OLS) & Multivariate Linear Regression**, and four supervised classification algorithms (**Random Forest, k-NN, RBF-SVM, and Multinomial Logistic Regression**), the system achieves **99.02% test accuracy** (**99.36% 5-fold cross-validation accuracy**) and provides an interactive **Plotly GUI Dashboard**.

## 🎯 Key Achievements
- **2,040 Spatiotemporal Observations** analyzed across 5 physiographic elevation zones (135 m to 4,600 m) over 34 years (1991–2024).
- **97.63% Variance Retained** via Principal Component Analysis (reducing 10 hydro-thermal parameters to 3 orthogonal components).
- **Optimal k = 3 Climatic Regimes** discovered via K-Means (Silhouette = **0.4941**, Davies-Bouldin = **0.6883**) with **88.04% concordance** against Ward's Hierarchical Clustering.
- **99.02% Classification Accuracy** using Random Forest (followed by **98.78%** with k-NN $k=5$, **98.54%** with RBF-SVM, and **98.29%** with Multinomial Logistic Regression).
- **Long-Term Linear Regression Trend Discovery:** Quantified asymmetric nocturnal warming (`Tmin`: **+0.423 °C/decade**, $R^2=0.6010, p<0.0001$ vs. `Tmax`: **+0.240 °C/decade**), Diurnal Temperature Range narrowing (**-0.184 °C/decade**), Elevation-Dependent Warming (**+0.244 °C/decade** in Lowland Plains to **+0.462 °C/decade** in the Alpine Cryospheric Belt), and annual rainfall intensification (**+253.07 mm/decade**).
- **Interactive Plotly GUI Dashboard:** Multi-tab visual analytics interface (`climate_analysis_plotly_dashboard.html` & `plotly_dashboard_gui.py`).

## 📁 Repository Structure
```
├── Assignment Question/                  # Coursework brief & requirements
├── Assignment Report/                    # Final Thesis Report (.docx and .pdf)
│   ├── Samip_Subedi_13705927.docx
│   └── Samip_Subedi_13705927.pdf
├── Proposal/                             # 1-Page IEEE Project Proposal (.pdf)
│   └── STW7072CEM_Machine_Learning_Proposal_13705927.pdf
├── Original Dataset/                     # Raw 1991-2024 Climate & Physiographic Datasets
├── Output_Figures/                       # 16 High-Resolution Publication Figures (.png)
├── Code Screenshots/                     # 12 Implementation Code Screenshots (.png)
├── climate_analysis_plotly_dashboard.html # Interactive Plotly GUI Dashboard WebApp
├── plotly_dashboard_gui.py               # Python Launcher for Plotly GUI Dashboard
├── machine_learning_assignment.ipynb     # Main Jupyter Notebook Implementation
├── machine_learning_assignment.py        # Complete Python Script Implementation
├── cleaned_climate_data_1991_2024.xlsx   # Preprocessed Spatiotemporal Dataset
├── data_with_clusters.xlsx               # K-Means & Hierarchical Clustering Results
├── data_with_labels.xlsx                 # CMTI & Regime-Labeled Dataset
├── model_comparison.csv                  # Supervised Classification Metrics
├── linear_regression_trends.csv          # OLS Linear Regression Trend Results (1991-2024)
├── *.pkl                                 # Trained Models (RF, k-NN, SVM, LR, LinReg, KMeans, PCA, Scaler)
└── README.md                             # Project Documentation
```

## 📊 Summary of Supervised Classification Performance
| Model | Train Accuracy | Test Accuracy | Precision | Recall | F1-Score | ROC-AUC | 5-Fold CV Mean ± Std |
|-------|----------------|---------------|-----------|--------|----------|---------|----------------------|
| **Random Forest (60 Trees)** | 99.82% | **99.02%** | 99.03% | 99.02% | 99.02% | 0.9998 | **99.36% ± 0.45%** |
| **k-NN (k = 5)** | 100.00% | **98.78%** | 98.81% | 98.78% | 98.78% | 0.9998 | **99.12% ± 0.48%** |
| **SVM (RBF Kernel)** | 99.02% | **98.54%** | 98.59% | 98.54% | 98.54% | 0.9999 | **98.63% ± 0.72%** |
| **Logistic Regression** | 97.85% | **98.29%** | 98.32% | 98.29% | 98.30% | 0.9995 | **97.94% ± 0.65%** |
