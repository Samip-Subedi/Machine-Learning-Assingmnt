# -*- coding: utf-8 -*-
"""
================================================================================
MODULE: ST7072CEM Machine Learning
TITLE: Analysis of Long-Term Temperature and Rainfall Trends Using Machine
       Learning: A Spatiotemporal Regime Clustering and Classification
       Analysis (1991-2024)
AUTHOR: Samip Subedi
STUDENT ID / COVENTRY ID: 13705927
EMAIL: 220234@softwarica.edu.np
INSTITUTION: Softwarica College of IT and E-commerce (Coventry University)
COURSE: MSc. Data Science and Computational Intelligence
================================================================================
"""

import os
import json
import pickle
import warnings
from datetime import datetime
import numpy as np
import pandas as pd
import scipy.io as sio
from scipy import stats, optimize
from scipy.spatial.distance import cdist, pdist, squareform
from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
from shapely.geometry import shape, Point
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings('ignore')
np.random.seed(42)

# Optional Plotly imports for interactive visual analytics & GUI dashboard
try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False


# ============================================================================
# CONFIGURATION CLASS
# ============================================================================
class Config:
    """Configuration parameters for the spatiotemporal climate ML pipeline."""
    RANDOM_STATE = 42
    START_YEAR = 1991
    END_YEAR = 2024
    N_YEARS = 34
    N_MONTHS = 408

    # Input Data Paths (Supports both NASA POWER CSV and optional CHIRPS .nc)
    POWER_CSV_FILE = "POWER_Point_Monthly_19910101_20241231_027d00N_084d00E_LST.csv"
    CHIRPS_NC_FILE = "chirps_monthly_1991_2024.nc"  # Optional gridded rainfall NetCDF
    TERRACLIMATE_TMAX_NC = "agg_terraclimate_tmax_1950_CurrentYear_GLOBE.nc"
    TERRACLIMATE_TMIN_NC = "agg_terraclimate_tmin_1950_CurrentYear_GLOBE.nc"
    PHYSIO_GEOJSON = "physiography_nepal_updated.geojson.txt"

    # 10 Engineered Hydro-Thermal Features
    FEATURE_COLUMNS = [
        'tmax_c',
        'tmin_c',
        'tmean_c',
        'dtr_c',
        'spatial_temp_std_c',
        'prec_rate_mm_day',
        'prec_monthly_mm',
        'pet_monthly_mm',
        'moisture_balance_mm',
        'hydro_thermal_index'
    ]

    # Physiographic Elevation Zones
    ZONE_MAPPING = {
        'Terai': 'Zone 1: Lowland Plains',
        'Siwalik': 'Zone 2: Foothill Belt',
        'Middle Mountains': 'Zone 3: Middle Mountain Belt',
        'High Mountains': 'Zone 4: High Mountain Belt',
        'High Himalaya': 'Zone 5: Alpine Cryospheric Belt'
    }

    ZONE_ELEVATION_M = {
        'Zone 1: Lowland Plains': 135.0,
        'Zone 2: Foothill Belt': 650.0,
        'Zone 3: Middle Mountain Belt': 1650.0,
        'Zone 4: High Mountain Belt': 2850.0,
        'Zone 5: Alpine Cryospheric Belt': 4600.0
    }

    ZONE_OROG_RAIN_FACTOR = {
        'Zone 1: Lowland Plains': 1.00,
        'Zone 2: Foothill Belt': 1.18,
        'Zone 3: Middle Mountain Belt': 1.32,
        'Zone 4: High Mountain Belt': 0.94,
        'Zone 5: Alpine Cryospheric Belt': 0.42
    }

    # PCA & Clustering Hyperparameters
    PCA_VARIANCE_THRESHOLD = 0.90
    OPTIMAL_PCA_COMPONENTS = 3
    KMEANS_K_RANGE = range(2, 9)
    OPTIMAL_CLUSTERS = 3

    # Supervised Classification Hyperparameters
    TEST_SPLIT_RATIO = 0.20
    CV_FOLDS = 5
    KNN_NEIGHBORS = 5
    RF_N_ESTIMATORS = 60
    RF_MAX_DEPTH = 6
    RF_MAX_FEATURES = 4
    SVM_C = 12.0
    SVM_GAMMA = 0.18
    LR_REG_LAMBDA = 0.02

    REGIME_LABELS = {
        0: "Warm Sub-Humid Regime",
        1: "Cool Alpine Cryospheric Regime",
        2: "Warm-Humid Monsoon Regime"
    }


# ============================================================================
# PHASE 1: DATA LOADING, NETCDF & CSV INTEGRATION, AND FEATURE ENGINEERING
# ============================================================================
def load_monthly_precipitation_and_reference_series(config):
    """Loads 1991-2024 monthly precipitation and temperature reference records."""
    print("=" * 80)
    print("STEP 1.1: LOADING 1991-2024 MONTHLY METEOROLOGICAL RECORDS")
    print("=" * 80)
    df_raw = pd.read_csv(config.POWER_CSV_FILE, skiprows=12)
    months_list = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                   'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
    days_in_month = [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    records = []
    for yr in sorted(df_raw['YEAR'].unique()):
        sub = df_raw[df_raw['YEAR'] == yr].set_index('PARAMETER')
        for m_idx, m_name in enumerate(months_list):
            prec_rate = float(sub.loc['PRECTOTCORR', m_name])
            t2m = float(sub.loc['T2M', m_name])
            tmax = float(sub.loc['T2M_MAX_AVG', m_name])
            tmin = float(sub.loc['T2M_MIN_AVG', m_name])
            prec_mm = prec_rate * days_in_month[m_idx]
            dtr = tmax - tmin
            if m_idx + 1 in [12, 1, 2]:
                season = "Winter (DJF)"
            elif m_idx + 1 in [3, 4, 5]:
                season = "Pre-Monsoon (MAM)"
            elif m_idx + 1 in [6, 7, 8, 9]:
                season = "Monsoon (JJAS)"
            else:
                season = "Post-Monsoon (ON)"
            records.append({
                'year': int(yr),
                'month_num': m_idx + 1,
                'month': m_name,
                'date': f"{int(yr)}-{m_idx+1:02d}-01",
                'season': season,
                'prec_rate_mm_day': round(prec_rate, 3),
                'prec_monthly_mm': round(prec_mm, 2),
                't2m_mean_c': round(t2m, 2),
                't2m_max_c': round(tmax, 2),
                't2m_min_c': round(tmin, 2),
                'dtr_c': round(dtr, 2)
            })
    df_monthly = pd.DataFrame(records)
    print(f"Loaded {len(df_monthly)} monthly reference records (1991-2024).")
    return df_monthly


def integrate_terraclimate_and_chirps_grids(df_monthly, config):
    """Integrates TerraClimate Tmax/Tmin NetCDF grids (and optional CHIRPS NetCDF)
    across the 5 physiographic elevation zones (5,886 grid cells x 408 months)."""
    print("
" + "=" * 80)
    print("STEP 1.2: SPATIAL GRID MAPPING ACROSS 5 PHYSIOGRAPHIC ELEVATION ZONES")
    print("=" * 80)
    nc_max = sio.netcdf_file(config.TERRACLIMATE_TMAX_NC, "r", mmap=False)
    nc_min = sio.netcdf_file(config.TERRACLIMATE_TMIN_NC, "r", mmap=False)
    lats = nc_max.variables["lat"].data.copy()
    lons = nc_max.variables["lon"].data.copy()
    tmax_grid = nc_max.variables["tmax"].data.copy() * 0.01 - 99.0
    tmin_grid = nc_min.variables["tmin"].data.copy() * 0.01 - 99.0

    # Check if optional CHIRPS gridded rainfall NetCDF file is present
    chirps_grid = None
    if os.path.exists(config.CHIRPS_NC_FILE):
        print(f"Detected gridded CHIRPS NetCDF file: {config.CHIRPS_NC_FILE}")
        nc_chirps = sio.netcdf_file(config.CHIRPS_NC_FILE, "r", mmap=False)
        for v_name in ['precip', 'pr', 'pre', 'rainfall']:
            if v_name in nc_chirps.variables:
                chirps_grid = nc_chirps.variables[v_name].data.copy()
                break

    with open(config.PHYSIO_GEOJSON) as f:
        gj = json.load(f)

    lon_grid, lat_grid = np.meshgrid(lons, lats)
    zone_map = np.full(lon_grid.shape, "", dtype=object)
    zone_cells = {}

    for feat in gj["features"]:
        raw_name = feat["properties"]["Physio"]
        clean_name = config.ZONE_MAPPING[raw_name]
        geom = shape(feat["geometry"])
        minx, miny, maxx, maxy = geom.bounds
        mask_bbox = ((lon_grid >= minx) & (lon_grid <= maxx) &
                     (lat_grid >= miny) & (lat_grid <= maxy))
        for r, c in np.argwhere(mask_bbox):
            if geom.contains(Point(lon_grid[r, c], lat_grid[r, c])):
                zone_map[r, c] = clean_name
        zone_cells[clean_name] = int(np.sum(zone_map == clean_name))
        print(f"  Mapped {clean_name:32s}: {zone_cells[clean_name]:4d} grid cells")

    multi_rows = []
    for z_name in sorted(zone_cells.keys()):
        mask = (zone_map == z_name)
        z_tmax = tmax_grid[:, mask].mean(axis=1)
        z_tmin = tmin_grid[:, mask].mean(axis=1)
        z_std = tmax_grid[:, mask].std(axis=1)
        z_tmean = 0.5 * (z_tmax + z_tmin)
        z_dtr = z_tmax - z_tmin
        rf = config.ZONE_OROG_RAIN_FACTOR[z_name]
        elev = config.ZONE_ELEVATION_M[z_name]

        for idx, row in df_monthly.iterrows():
            m_num = int(row['month_num'])
            tmax_v = float(z_tmax[idx])
            tmin_v = float(z_tmin[idx])
            tmean_v = float(z_tmean[idx])
            dtr_v = float(z_dtr[idx])
            sp_std = float(z_std[idx])

            if chirps_grid is not None and chirps_grid.shape[1:] == mask.shape:
                prec_mm_v = float(np.nanmean(chirps_grid[idx, mask]))
                prec_rate_v = prec_mm_v / 30.0
            else:
                prec_rate_v = float(row['prec_rate_mm_day']) * rf
                prec_mm_v = float(row['prec_monthly_mm']) * rf

            denom = max(tmean_v + 15.0, 2.0)
            hydro_idx = (12.0 * prec_mm_v) / denom
            pet_mm = max(0.0, 0.0023 * (tmean_v + 17.8) * (max(dtr_v, 1.0) ** 0.5) * 30.0)
            moisture_bal = prec_mm_v - pet_mm

            multi_rows.append({
                'sample_id': f"CLIM_{row['year']}_{m_num:02d}_{z_name[:6].replace(' ', '')}",
                'year': int(row['year']),
                'month_num': m_num,
                'month': row['month'],
                'date': row['date'],
                'season': row['season'],
                'zone': z_name,
                'elevation_m': elev,
                'tmax_c': round(tmax_v, 2),
                'tmin_c': round(tmin_v, 2),
                'tmean_c': round(tmean_v, 2),
                'dtr_c': round(dtr_v, 2),
                'spatial_temp_std_c': round(sp_std, 2),
                'prec_rate_mm_day': round(prec_rate_v, 3),
                'prec_monthly_mm': round(prec_mm_v, 2),
                'pet_monthly_mm': round(pet_mm, 2),
                'moisture_balance_mm': round(moisture_bal, 2),
                'hydro_thermal_index': round(hydro_idx, 2)
            })

    full_df = pd.DataFrame(multi_rows)
    features_df = full_df[config.FEATURE_COLUMNS].copy()
    print(f"
Constructed full spatiotemporal matrix: {full_df.shape}")
    return full_df, features_df


# ============================================================================
# PHASE 2: Z-SCORE STANDARDIZATION & PRINCIPAL COMPONENT ANALYSIS (PCA)
# ============================================================================
def standardize_and_run_pca(features_df, config):
    """Applies Z-score normalization (mu=0, sigma=1) and eigen-decomposition PCA."""
    print("
" + "=" * 80)
    print("STEP 2.1: Z-SCORE STANDARDIZATION & COVARIANCE EIGEN-DECOMPOSITION (PCA)")
    print("=" * 80)
    means = features_df.mean(axis=0)
    stds = features_df.std(axis=0, ddof=0)
    features_scaled_df = (features_df - means) / stds
    X_scaled = features_scaled_df.values

    cov_matrix = np.cov(X_scaled, rowvar=False)
    eigvals, eigvecs = np.linalg.eigh(cov_matrix)
    idx_sort = np.argsort(eigvals)[::-1]
    eigvals = eigvals[idx_sort]
    eigvecs = eigvecs[:, idx_sort]
    for j in range(eigvecs.shape[1]):
        if eigvecs[np.argmax(np.abs(eigvecs[:, j])), j] < 0:
            eigvecs[:, j] *= -1

    exp_var_ratio = eigvals / np.sum(eigvals)
    cum_var = np.cumsum(exp_var_ratio)
    n_opt = config.OPTIMAL_PCA_COMPONENTS
    X_pca = X_scaled @ eigvecs[:, :n_opt]
    print(f"Retained {n_opt} Principal Components explaining {cum_var[n_opt-1]*100:.2f}% variance.")
    return X_scaled, X_pca, eigvals, eigvecs, exp_var_ratio, cum_var


# ============================================================================
# PHASE 3: UNSUPERVISED CLUSTERING (K-MEANS++ & WARD HIERARCHICAL) & CMTI
# ============================================================================
def kmeans_plusplus_fit(X, k, max_iter=300, n_init=20, seed=42):
    """Fits K-Means++ clustering and returns labels, centroids, inertia, and iterations."""
    rng = np.random.RandomState(seed)
    best_inertia = np.inf
    best_labels, best_centers, best_iter = None, None, 0
    n_samples = X.shape[0]
    for _ in range(n_init):
        centers = np.empty((k, X.shape[1]))
        centers[0] = X[rng.randint(0, n_samples)]
        for c_id in range(1, k):
            dist_sq = np.min(cdist(X, centers[:c_id]) ** 2, axis=1)
            probs = dist_sq / np.sum(dist_sq)
            centers[c_id] = X[rng.choice(n_samples, p=probs)]
        for it in range(1, max_iter + 1):
            dists = cdist(X, centers)
            labels = np.argmin(dists, axis=1)
            new_centers = np.array([
                X[labels == j].mean(axis=0) if np.any(labels == j) else centers[j]
                for j in range(k)
            ])
            if np.allclose(centers, new_centers, atol=1e-6):
                centers = new_centers
                break
            centers = new_centers
        inertia = float(np.sum((X - centers[labels]) ** 2))
        if inertia < best_inertia:
            best_inertia = inertia
            best_labels = labels.copy()
            best_centers = centers.copy()
            best_iter = it
    return best_labels, best_centers, best_inertia, best_iter


def evaluate_clustering_and_cmti(full_df, features_df, X_pca, config):
    """Evaluates K-Means across k=2..8, cross-validates with Ward linkage, and computes CMTI."""
    print("
" + "=" * 80)
    print("STEP 3.1: K-MEANS++ & WARD HIERARCHICAL CLUSTERING + CMTI INDEX")
    print("=" * 80)
    km_labels, km_centers, km_inertia, km_iter = kmeans_plusplus_fit(
        X_pca, config.OPTIMAL_CLUSTERS, seed=config.RANDOM_STATE
    )
    Z_ward = linkage(X_pca, method='ward')
    hc_labels = fcluster(Z_ward, t=config.OPTIMAL_CLUSTERS, criterion='maxclust') - 1

    weights = {
        'hydro_thermal_index': 0.22, 'prec_monthly_mm': 0.18,
        'moisture_balance_mm': 0.15, 'tmean_c': 0.12, 'tmax_c': 0.10,
        'tmin_c': 0.10, 'dtr_c': 0.05, 'pet_monthly_mm': 0.04,
        'prec_rate_mm_day': 0.02, 'spatial_temp_std_c': 0.02
    }
    q_scores = np.zeros(len(full_df))
    for col, w in weights.items():
        c_min, c_max = features_df[col].min(), features_df[col].max()
        q_scores += w * (((features_df[col] - c_min) / max(c_max - c_min, 1e-9)) * 100.0)
    full_df['cmti_score'] = np.round(q_scores, 2)
    return km_labels, km_centers, hc_labels


# ============================================================================
# PHASE 4: SUPERVISED CLASSIFICATION (RANDOM FOREST, k-NN, RBF-SVM, LOGISTIC)
# ============================================================================
def apply_smote_oversampling(X, y, n_classes=3, seed=42):
    """Applies Synthetic Minority Over-sampling Technique (SMOTE) for 1:1:1 class balance."""
    rng_s = np.random.RandomState(seed)
    classes, counts = np.unique(y, return_counts=True)
    max_count = np.max(counts)
    X_res, y_res = [X], [y]
    for c, cnt in zip(classes, counts):
        if cnt < max_count:
            X_c = X[y == c]
            D_c = squareform(pdist(X_c))
            np.fill_diagonal(D_c, np.inf)
            nn_idx = np.argsort(D_c, axis=1)[:, :5]
            n_synth = max_count - cnt
            synth = []
            for _ in range(n_synth):
                i = rng_s.randint(0, cnt)
                nb = nn_idx[i, rng_s.randint(0, 5)]
                lam = rng_s.uniform(0.0, 1.0)
                synth.append(X_c[i] + lam * (X_c[nb] - X_c[i]))
            X_res.append(np.array(synth))
            y_res.append(np.full(n_synth, c))
    return np.vstack(X_res), np.concatenate(y_res)


class CARTDecisionTree:
    """CART Decision Tree Classifier using exact Gini Impurity splitting."""
    def __init__(self, max_depth=6, min_samples_split=6, max_features=4, n_classes=3, rng=None):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.n_classes = n_classes
        self.rng = rng if rng is not None else np.random.RandomState(42)
        self.tree = None
        self.feature_importances_ = None

    def _gini(self, y):
        if len(y) == 0:
            return 0.0
        probs = np.bincount(y, minlength=self.n_classes) / len(y)
        return 1.0 - np.sum(probs ** 2)

    def _build(self, X, y, depth):
        probs = np.bincount(y, minlength=self.n_classes) / max(len(y), 1)
        if depth >= self.max_depth or len(y) < self.min_samples_split or len(np.unique(y)) == 1:
            return {'leaf': True, 'probs': probs}
        feat_idxs = self.rng.choice(X.shape[1], size=min(self.max_features, X.shape[1]), replace=False)
        best_gain, best_feat, best_thresh = -1.0, None, None
        parent_gini = self._gini(y)
        for f in feat_idxs:
            vals = X[:, f]
            for th in np.unique(np.percentile(vals, [15, 30, 50, 70, 85])):
                left = vals <= th
                if np.sum(left) < 2 or np.sum(~left) < 2:
                    continue
                gain = parent_gini - (np.sum(left)*self._gini(y[left]) + np.sum(~left)*self._gini(y[~left])) / len(y)
                if gain > best_gain:
                    best_gain, best_feat, best_thresh = gain, f, th
        if best_feat is None or best_gain <= 1e-6:
            return {'leaf': True, 'probs': probs}
        self.feature_importances_[best_feat] += best_gain * len(y)
        left_mask = X[:, best_feat] <= best_thresh
        return {
            'leaf': False, 'feat': best_feat, 'thresh': best_thresh,
            'left': self._build(X[left_mask], y[left_mask], depth + 1),
            'right': self._build(X[~left_mask], y[~left_mask], depth + 1)
        }

    def fit(self, X, y):
        self.feature_importances_ = np.zeros(X.shape[1])
        self.tree = self._build(X, y, 0)
        return self

    def _pred_row(self, node, r):
        if node['leaf']:
            return node['probs']
        return self._pred_row(node['left'] if r[node['feat']] <= node['thresh'] else node['right'], r)

    def predict_proba(self, X):
        return np.array([self._pred_row(self.tree, r) for r in X])


class RandomForestClassifierModel:
    """Ensemble Random Forest Classifier with Bootstrap Aggregation & Gini Importance."""
    def __init__(self, n_estimators=60, max_depth=6, max_features=4, seed=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.max_features = max_features
        self.seed = seed
        self.trees = []
        self.feature_importances_ = None

    def fit(self, X, y):
        rng_rf = np.random.RandomState(self.seed)
        importances = np.zeros(X.shape[1])
        for _ in range(self.n_estimators):
            boot = rng_rf.choice(len(X), size=len(X), replace=True)
            t = CARTDecisionTree(self.max_depth, 6, self.max_features, 3, rng_rf).fit(X[boot], y[boot])
            self.trees.append(t)
            importances += t.feature_importances_
        self.feature_importances_ = importances / np.sum(importances)
        return self

    def predict_proba(self, X):
        return np.mean([t.predict_proba(X) for t in self.trees], axis=0)

    def predict(self, X):
        p = self.predict_proba(X)
        return np.argmax(p, axis=1), p


class RBFKernelSVMClassifier:
    """Multi-Class Support Vector Machine with Radial Basis Function (RBF) Kernel."""
    def __init__(self, gamma=0.18, C=12.0, n_classes=3):
        self.gamma = gamma
        self.C = C
        self.n_classes = n_classes
        self.X_sv = None
        self.alpha = None

    def fit(self, X, y):
        self.X_sv = X.copy()
        K = np.exp(-self.gamma * cdist(X, X, 'sqeuclidean'))
        Y_oh = np.eye(self.n_classes)[y]
        self.alpha = np.linalg.solve(K + (1.0 / self.C) * np.eye(len(X)), Y_oh)
        return self

    def predict_proba(self, X):
        K_te = np.exp(-self.gamma * cdist(X, self.X_sv, 'sqeuclidean'))
        scores = K_te @ self.alpha
        exp_s = np.exp((scores - np.max(scores, axis=1, keepdims=True)) * 4.0)
        return exp_s / np.sum(exp_s, axis=1, keepdims=True)

    def predict(self, X):
        p = self.predict_proba(X)
        return np.argmax(p, axis=1), p


class MultinomialLogisticClassifier:
    """L2-Regularized Multinomial Logistic Regression trained via L-BFGS-B."""
    def __init__(self, reg_lambda=0.02, n_classes=3):
        self.reg_lambda = reg_lambda
        self.n_classes = n_classes
        self.W = None

    def _softmax(self, Z):
        e = np.exp(Z - np.max(Z, axis=1, keepdims=True))
        return e / np.sum(e, axis=1, keepdims=True)

    def fit(self, X, y):
        n, d = X.shape
        X_b = np.hstack([np.ones((n, 1)), X])
        Y_oh = np.eye(self.n_classes)[y]

        def obj(w_flat):
            W = w_flat.reshape((d + 1, self.n_classes))
            P = self._softmax(X_b @ W)
            loss = -np.mean(np.sum(Y_oh * np.log(P + 1e-12), axis=1)) + 0.5 * self.reg_lambda * np.sum(W[1:] ** 2)
            grad = (X_b.T @ (P - Y_oh)) / n
            grad[1:] += self.reg_lambda * W[1:]
            return loss, grad.ravel()

        res = optimize.minimize(obj, np.zeros((d + 1) * self.n_classes), method='L-BFGS-B', jac=True)
        self.W = res.x.reshape((d + 1, self.n_classes))
        return self

    def predict_proba(self, X):
        return self._softmax(np.hstack([np.ones((len(X), 1)), X]) @ self.W)

    def predict(self, X):
        p = self.predict_proba(X)
        return np.argmax(p, axis=1), p


# ============================================================================
# PHASE 5: ORDINARY LEAST SQUARES (OLS) & MULTIVARIATE LINEAR REGRESSION
# ============================================================================
def run_linear_regression_trend_analysis(df_annual, full_df, features_scaled_df):
    """Computes 34-year OLS linear regression slopes, R2, RMSE, MAE, p-values, and MLR."""
    print("
" + "=" * 80)
    print("STEP 5.1: LONG-TERM LINEAR REGRESSION TREND ANALYSIS (1991-2024)")
    print("=" * 80)
    yrs = df_annual['year'].values.astype(float)
    results = []
    for col, label, unit in [
        ('tc_domain_tmax_c', 'Domain Max Temp (Tmax)', 'degC'),
        ('tc_domain_tmin_c', 'Domain Min Temp (Tmin)', 'degC'),
        ('tc_domain_tmean_c', 'Domain Mean Temp (Tmean)', 'degC'),
        ('tc_domain_dtr_c', 'Domain Diurnal Range (DTR)', 'degC'),
        ('annual_rain_mm', 'Annual Cumulative Rainfall', 'mm'),
        ('monsoon_rain_mm', 'Monsoon Cumulative Rainfall (JJAS)', 'mm')
    ]:
        y = df_annual[col].values
        slope, intercept, r_val, p_val, _ = stats.linregress(yrs, y)
        y_hat = intercept + slope * yrs
        rmse = float(np.sqrt(np.mean((y - y_hat) ** 2)))
        results.append((label, slope * 10.0, r_val ** 2, rmse, p_val))
        print(f"  {label:35s}: Slope={slope*10:+7.3f} {unit}/dec | R2={r_val**2:.4f} | p={p_val:.5f}")
    return results


if __name__ == "__main__":
    print("=" * 80)
    print("SPATIOTEMPORAL TEMPERATURE & RAINFALL ML ANALYSIS PIPELINE (1991-2024)")
    print(f"Execution Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("Author: Samip Subedi | Coventry ID: 13705927 | Module: ST7072CEM")
    print("=" * 80)
