# ==============================================================================
# INTERACTIVE PLOTLY GUI DASHBOARD LAUNCHER
# Title: Analysis of Long-Term Temperature and Rainfall Trends Using Machine Learning
# Student: Samip Subedi (Coventry ID: 13705927 | Email: 220234@softwarica.edu.np)
# ==============================================================================

import os
import webbrowser
import http.server
import socketserver

DASHBOARD_FILE = "climate_analysis_plotly_dashboard.html"
PORT = 8050

def launch_plotly_dashboard():
    """Launches the interactive Plotly GUI Dashboard in the local web browser."""
    abs_path = os.path.abspath(DASHBOARD_FILE)
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Dashboard file not found: {abs_path}")
    print("="*75)
    print("LAUNCHING INTERACTIVE PLOTLY GUI DASHBOARD")
    print("Title: Analysis of Long-Term Temperature and Rainfall Trends Using Machine Learning")
    print("Author: Samip Subedi (Coventry ID: 13705927)")
    print(f"Opening {abs_path} in default browser...")
    print("="*75)
    webbrowser.open(f"file://{abs_path}")

if __name__ == "__main__":
    launch_plotly_dashboard()
